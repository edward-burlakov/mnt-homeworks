The `./roles` symlink helps Ansible find local roles used by files from
current directory.
